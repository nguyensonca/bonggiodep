---
title: "Page B"
permalink: /page-b/
date: 2011-06-23T18:39:14+00:00
---

(lorem ipsum)